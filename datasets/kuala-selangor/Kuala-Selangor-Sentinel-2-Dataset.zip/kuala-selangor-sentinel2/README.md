# Kuala Selangor satellite dataset package

## Coverage and satellite identity

This package concerns the **app's 500 x 500 m study footprint** around Kuala Selangor Nature Park, centred at latitude **3.33656**, longitude **101.23674** (WGS84). It does not cover all farms, the whole park, or the Kuala Selangor district. `study-area.geojson` defines the requested footprint, not a surveyed land-ownership boundary.

- Source mission: **Copernicus Sentinel-2**.
- Platforms present: **Sentinel-2A, Sentinel-2B and Sentinel-2C**.
- Instrument: **MSI (Multispectral Instrument)**.
- Product: **Level-2A surface reflectance**, accessed through Earth Search collection `sentinel-2-l2a`.
- Tile: **47NQD**. The imagery exports use **EPSG:32647**, WGS84 / UTM zone 47N.
- Catalogue retrieval: 2026-10-17T03:10:38.945038+00:00.
- The site's current acquisition menu contains **20 scene records**, 31 July to 14 October 2026: 4 Sentinel-2A, 8 Sentinel-2B and 8 Sentinel-2C.
- Complete matching index returned by this particular collection: **887 records**, **14 January 2017 to 14 October 2026**. All catalogue pages were followed until no next page remained. This is not a claim to include every product ever acquired by the Sentinel-2 mission, other catalogues or other processing collections.
- Archive platforms: 399 Sentinel-2A, 423 Sentinel-2B, 65 Sentinel-2C. Records are catalogue products, not necessarily unique passes or independent monitoring events.

## The image currently selected in the browser

**Sentinel-2C**, scene **S2C_47NQD_20260904_0_L2A**.

Acquired **4 September 2026 at 03:47:23 UTC / 11:47:23 MYT**. This is an acquisition date, not the time the user viewed or captured the screen. The native catalogue reports 21.5856% cloud across the source tile. The app-style extraction finds 11.92% usable clear land in the small study footprint, mean usable-land NDVI 0.4800, and 7.72% of the study footprint meeting its vegetation threshold. Tile-cloud percentage and local usable-land percentage measure different things.

## What is physically included

### Imagery data for all 20 dates shown by the app

Each folder under `website-imagery/SCENE_ID/` includes:

| File | Contents |
|---|---|
| `true-colour.tif` | Georeferenced RGB display data from the source visual/TCI asset |
| `true-colour.png` | Faithful 50 x 50 RGB image |
| `true-colour-nearest-preview.png` | Enlarged 500 x 500 viewing copy; nearest-neighbour enlargement adds no detail |
| `red-B04-dn.tif` | Red-band B04 digital numbers, uint16 |
| `nir-B08-dn.tif` | Near-infrared B08 digital numbers, uint16 |
| `scene-classification.tif` | SCL categories, resampled from native 20 m to the app grid |
| `usable-clear-land-mask.tif` | App mask, 1 usable clear land and 0 excluded |
| `NDVI.tif` | Derived float32 vegetation index; invalid values are -9999 |
| `pixels.csv` | 2,500 output-grid records including coordinates, raw bands, reflectance, SCL, NDVI, RGB and validity |
| `scene.json` | Per-scene satellite, acquisition, source assets, scaling/offset, output extent, quality and projection |
| `rgb.raw` | RGB uint8 bytes in row-major order, 50 x 50 x 3 |

The extraction follows the current website implementation. It uses the app's 50 x 50 output grid and nearest-neighbour resampling over the projected bounding box. Ground sampling is approximately 10 m; exact output spacing is recorded in `scene.json`. Output coordinates refer to the exported grid, not separately surveyed locations or exact original sensor pixel centres. A resampled 20 m classification does not gain 10 m source accuracy.

### Full archive inventory and original links

- `archive-scenes.csv`: all 887 matching records, satellite identity, timestamps, tile cloud, metadata URL and original links for the four app inputs.
- `all-original-asset-links.csv`: every asset advertised by those 887 records, including additional spectral bands, metadata, thumbnails and native-resolution products where listed.
- `archive-stac.geojson`: complete returned STAC records with metadata and asset descriptions.
- `website-20-scenes.csv` and `website-20-scenes.geojson`: the exact latest-20 catalogue query used to match the website menu.
- `website-observation-quality.csv`: calculated local-footprint quality for the 20 exported observations.
- `dataset-summary.json`: scope, counts, retrieval time and pagination provenance.

**The full-resolution imagery for all 887 historical records is not bundled.** Their original asset locations are supplied. Actual clipped image data is bundled for the 20 acquisitions in the current website menu. Some original asset addresses are `s3://` URIs requiring an S3-compatible client and the provider's access configuration. HTTP COG links can be used by suitable GIS software or for downloads. Assets outside the four app inputs have not all been downloaded or individually tested.

## Reflectance, NDVI and masking

For red and NIR, apply each asset's scale and offset from `scene.json` or its STAC metadata:

```text
reflectance = digital_number * asset_scale + asset_offset
NDVI = (NIR_reflectance - red_reflectance) / (NIR_reflectance + red_reflectance)
```

No-data values use the asset metadata. The app allows SCL **4 (vegetation)** and **5 (bare soil)**, requires finite nonnegative reflectance and a positive denominator, and excludes other classes from its land NDVI. It clips valid NDVI to [-1, 1]. The app uses NDVI >= 0.35 as an illustrative vegetation threshold, not a mangrove species classifier.

`pixels.csv` uses zero-based row and column. Rows run north to south, columns west to east. Longitude/latitude are WGS84 decimal degrees. Easting/northing use the scene's output UTM CRS in metres. Invalid NDVI/reflectance values are blank in CSV; the `usable_clear_land` column identifies usable NDVI pixels. An NDVI value of zero is distinct from missing data.

SCL legend: 0 no data, 1 saturated/defective, 2 dark-area/topographic-shadow class (definition depends on processing baseline), 3 cloud shadow, 4 vegetation, 5 bare soil/non-vegetated land, 6 water, 7 unclassified, 8 medium-probability cloud, 9 high-probability cloud, 10 thin cirrus, 11 snow/ice. Retain original processing metadata when interpreting older products.

## What is not a satellite measurement here

Water salinity, oxygen, turbidity, pH, water temperature, soil salinity/moisture sliders, tree heights/counts/ages, wellness stress scores and carbon eligibility masks are **not measured by these exported satellite inputs**. App model outputs, sensor examples and simulated verifier decisions must remain separate datasets. There is no Sentinel-1 radar or Landsat input in this current open-imagery view.

## How to open the data

1. In QGIS or another GeoTIFF-compatible GIS, open the study-area GeoJSON and a scene's `.tif` files.
2. Use `NDVI.tif` for the derived vegetation layer and the mask for usability. Preserve -9999 as no data.
3. Open the CSV inventory in Excel or another table viewer to filter satellite and acquisition date.
4. Use original links or STAC records for full-resolution source tiles or additional bands.
5. Do not infer individual-tree positions or carbon-credit eligibility from a 10 m RGB/NDVI pixel.

## Sources and attribution

Contains modified Copernicus Sentinel data. Processing/distribution metadata: Earth Search / Element 84 and AWS Open Data.

- ESA mission and MSI overview: https://www.esa.int/Applications/Observing_the_Earth/Copernicus/Sentinel-2
- Copernicus product definitions: https://sentiwiki.copernicus.eu/web/s2-products
- Earth Search source and collection notes: https://github.com/Element84/earth-search
- AWS dataset entry: https://registry.opendata.aws/sentinel-2-l2a-cogs/
- Catalogue: https://earth-search.aws.element84.com/v1

This export does not change or commit website code. `SHA256SUMS.txt` records the packaged files' digests.
